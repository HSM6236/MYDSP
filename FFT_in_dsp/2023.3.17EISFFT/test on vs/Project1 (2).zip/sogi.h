#ifndef APP_SOGI_H_
#define APP_SOGI_H_

#define N_SIGN_SOGI 2560


void run_sogi(float* input, float* output, int data_len);


#endif